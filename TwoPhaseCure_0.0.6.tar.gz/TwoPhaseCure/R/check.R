check_data <- function(x, nm="data") {

  if (!is.data.frame(x)) stop(paste0("ERROR: ", nm, " must be a data frame"))
  if (!nrow(x)) stop(paste0("ERROR: ", nm, " contains no rows"))
  if (!ncol(x)) stop(paste0("ERROR: ", nm, " contains no columns"))
  NULL
}

check_col <- function(x, nm, data, pos=0, bin=0, num=1) {

  if (!isString(x)) stop(paste0("ERROR: ", nm, " must be a column name in the data"))
  valid <- colnames(data)
  if (!(x %in% valid)) {
    msg <- paste0("ERROR: ", nm, "=", getQuotedVecStr(x), " not found in the data")
    stop(msg)
  }
  vec <- data[, x, drop=TRUE]
  if (num && !is.numeric(vec)) {
    stop(paste0("ERROR: ", nm, "=", getQuotedVecStr(x), " must be numeric"))
  }

  if (pos) {
    tmp <- vec <= 0
    tmp[is.na(tmp)] <- FALSE
    if (any(tmp)) stop(paste0("ERROR: ", nm, "=", getQuotedVecStr(x), " must be positive"))
  }

  if (bin) {
    tmp <- is.finite(vec) & !(vec %in% 0:1)
    if (any(tmp)) {
      msg <- paste0("ERROR: ", nm, "=", getQuotedVecStr(x), " must be coded 0-1")
      stop(msg)
    }
  }

  NULL
}

check_cols <- function(x, nm, data, n=0, min=0, num=0) {

  len <- length(x)
  if (min && (len < min)) {
    msg <- paste0("ERROR: ", nm, " must be a vector of length >= ", min)
    stop(msg) 
  }
  if (len) {
    if (n && (n != len)) {
      msg <- paste0("ERROR: ", nm, " must be a vector of length ", n)
      stop(msg) 
    }
    if (!is.vector(x) || !is.character(x)) {
      msg <- paste0("ERROR: ", nm, " must be a vector of column names in the data")
      stop(msg) 
    }
    for (v in x) check_col(v, nm, data, pos=0, bin=0, num=num) 
    if (len != length(unique(x))) {
      msg <- paste0("ERROR: ", nm, " does not contain unique column names")
      stop(msg) 
    }
  }
  NULL
}

check_time.col <- function(x, data, nm="time.col") {

  check_col(x, nm, data, pos=1, bin=0)
  NULL
}

check_status.col <- function(x, data, nm="status.col") {

  check_col(x, nm, data, pos=0, bin=1)
  NULL
}

check_exposure.col <- function(x, data, nm="exposure.col") {

  check_col(x, nm, data, pos=0, bin=0)
  NULL
}



getQuotedVecStr <- function(x, sep=",") {
  ret <- paste0("'", x, "'")
  ret <- paste0(ret, collapse=sep)
  ret
}

isString <- function(x) {
  (length(x) == 1) && is.character(x)
}

check_num <- function(x, name, len=1, pos=1, min=NULL, max=NULL) {

  xlen <- length(x)
  if (!len && !xlen) return(NULL)
  if (len && (xlen != len)) {
    stop(paste0("ERROR: ", name, " must be a numeric value"))
  }
  if (!is.finite(x)) stop(paste0("ERROR: ", name, " must be a numeric value"))
  if (pos && (x <= 0)) {
    stop(paste0("ERROR: ", name, " must be a positive value"))
  }

  if (length(min) && (x < min)) {
    stop(paste0("ERROR: ", name, " must be >= ", min))
  }
  if (length(max) && (x > max)) {
    stop(paste0("ERROR: ", name, " must be <= ", max))
  }

  NULL
}

check_int <- function(x, nm, len=1, pos=1, min=NULL, max=NULL) {

  check_num(x, nm, len=len, pos=pos, min=min, max=max)
  if (x != floor(x)) {
    msg <- paste0("ERROR: ", nm, " must be an integer")
    stop(msg)
  }
  NULL
}

check_log <- function(x, name) {

  if (length(x) != 1) stop(paste0("ERROR: ", name, " must be TRUE or FALSE"))
  tmp <- x %in% c(TRUE, FALSE)
  if (!tmp) stop(paste0("ERROR: ", name, " must be TRUE or FALSE"))
  NULL
}

check_str <- function(x, nm, valid) {
  
  if (!isString(x)) {
    err <- getQuotedVecStr(valid, sep=",")
    msg <- paste0("ERROR: ", nm, " must be one of ", err)
    stop(msg)
  }
  if (!(x %in% valid)) {
    err <- getQuotedVecStr(valid, sep=",")
    msg <- paste0("ERROR: ", nm, " must be one of ", err)
    stop(msg)
  }
  NULL
}

check_phaseII.design <- function(x) {

  valid <- c("RSD1", "RSD2", "BRSD")
  check_str(x, "phaseII.design", valid)
  NULL
}

check_scenario <- function(x) {

  valid <- c("a", "b", "c")
  check_str(x, "scenario", valid)
  NULL
}

check_exposure.type <- function(x) {

  nm    <- "exposure.type"
  if (length(x)) {
    valid <- c("binary", "cont")
    check_str(x, nm, valid)
  }
  NULL
}

check_cuts <- function(x) {

  nm  <- "pwc.cutpoints"
  def <- c(1/3, 2/3)
  if (!length(x)) x <- def
  if (!is.numeric(x) || !is.vector(x)) {
    stop(paste0("ERROR: ", nm, " must be a numeric vector"))
  }
  tmp <- (x < 0) | (x > 1) | !is.finite(x)
  tmp[is.na(tmp)] <- TRUE
  if (any(tmp)) {
    stop(paste0("ERROR: ", nm, " must have values in [0, 1]"))
  }

  x
}