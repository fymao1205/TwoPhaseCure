

# max. obs loglik

rldt_est_pwc_H0.f <- function(del, time, X0, Z0, brks){
  
  len = length(brks)+1
  len.et2=(ncol(Z0))
  len.be2=(ncol(X0))
  
  obj.f <- function(para){
    
    alp = exp(para[1:len]) #c(exp(para[1]), 1)
    #eta1 = para[len+1]
    #beta1 = para[len+2]
    
    eta2 = para[len+(1:len.et2)]
    beta2 = para[len+len.et2+(1:len.be2)]
    #muX1=para[len+ncol(Z0)+ncol(X0)+1]
    #sigma2 = exp(para[len+ncol(Z0)+ncol(X0)+2])
    
    muZ=drop(eta2%*%t(Z0)); muT=drop(beta2%*%t(X0))
    
    #res0 <- logLn_obs_pwc_norm_H0( del, time, muZ, muT, alp, brks)
    res0 <- RtoC_logLn_obs_pwc_norm_H0( del, time, muZ, muT, alp, brks)
    
    res <- -sum(res0)
    
    #print(para)
    #print(res)
    
    return(res)
    
  }
  
  #est <- optim(par=rep(0.01,len+len.et2+len.be2), obj.f, method=("L-BFGS-B"), control = list(factr=1e2))
  est <- nlm(f=obj.f, p=rep(0.01, len+len.et2+len.be2), gradtol = 1e-03)
  return(est)
}


rldt_est_pwc_withV.f <- function(ini, scen, del, time, x, X0, Z0, V, brks){
  
  len=length(brks)+1
  len.et2=ncol(Z0)
  len.be2=ncol(X0)
  len.ga2=ncol(V) # V should contain the 1s column for intercept
  
  if(is.null(ini)){
    if(scen=="sc"){
      ini=rep(0.01,len+3+len.et2+len.be2+len.ga2)
    }else{
      ini=rep(0.01,len+2+len.et2+len.be2+len.ga2)
    }
    
  }
  
  r <- ifelse(is.na(x), 0, 1)

  #nr0=sum(1-r)
  if(scen=="sc"){
    obj.f <- function(para){
   
      #para=round(para,4)
      alp = exp(para[1:len]) #c(exp(para[1]), 1)
      eta1 = para[len+1]
      beta1 = para[len+2]
      
      eta2 = para[len+2+(1:len.et2)]
      beta2 = para[len+2+len.et2+(1:len.be2)]
      gam2 = para[len+2+len.et2+len.be2+(1:len.ga2)]
      muX1=drop(gam2 %*% t(V))
      sigma2 = exp(para[len+2+len.et2+len.be2+len.ga2+1])
      muZ=drop(eta2%*%t(Z0)); muT=drop(beta2%*%t(X0))
      
      #res0 <- logLn_obs_pwc_norm_withV(r, del, time, x, eta1, beta1, muZ, muT, muX1, sigma2, alp, brks)
      res0 <- RtoC_logLn_obs_pwc_norm_withV(r, del, time, x, eta1, beta1, muZ, muT, muX1, sigma2, alp, brks)
      
      res <- -sum(res0)
      #  res<- -mean(res0)
      
      #print(para)
      #print(res)
      
      return(res)
      
    }
  }else if(scen=="sa"){
    
    obj.f <- function(para){
      
      #para=round(para,4)
      alp = exp(para[1:len]) #c(exp(para[1]), 1)
      eta1 = para[len+1]
      beta1 = 0#para[len+2]
      
      eta2 = para[len+1+(1:len.et2)]
      beta2 = para[len+1+len.et2+(1:len.be2)]
      gam2 = para[len+1+len.et2+len.be2+(1:len.ga2)]
      muX1=drop(gam2 %*% t(V))
      sigma2 = exp(para[len+1+len.et2+len.be2+len.ga2+1])
      
      muZ=drop(eta2%*%t(Z0)); muT=drop(beta2%*%t(X0))
      
      #res0 <- logLn_obs_pwc_norm_withV(r, del, time, x, eta1, beta1, muZ, muT, muX1, sigma2, alp, brks)
      res0 <- RtoC_logLn_obs_pwc_norm_withV(r, del, time, x, eta1, beta1, muZ, muT, muX1, sigma2, alp, brks)
      
      res <- -sum(res0)
      
      #print(para)
      #print(res)
      
      return(res)
      
    }
  }else if(scen=="sb"){
    
    obj.f <- function(para){
      
      #para=round(para,4)
      alp = exp(para[1:len]) #c(exp(para[1]), 1)
      eta1 = 0#para[len+1]
      beta1 = para[len+1]
      
      eta2 = para[len+1+(1:len.et2)]
      beta2 = para[len+1+len.et2+(1:len.be2)]
      gam2 = para[len+1+len.et2+len.be2+(1:len.ga2)]
      muX1= drop(gam2 %*% t(V))
      sigma2 = exp(para[len+1+len.et2+len.be2+len.ga2+1])
      
      muZ=drop(eta2%*%t(Z0)); muT=drop(beta2%*%t(X0))
      
      #res0 <- logLn_obs_pwc_norm_withV(r, del, time, x, eta1, beta1, muZ, muT, muX1, sigma2, alp, brks)
      res0 <- RtoC_logLn_obs_pwc_norm_withV(r, del, time, x, eta1, beta1, muZ, muT, muX1, sigma2, alp, brks)
      

      res <- -sum(res0)
      
      #print(para)
      #print(res)
      
      return(res)
      
    }
  }
  
  est <- optim(par=ini, obj.f, method=("L-BFGS-B"), hessian=TRUE)

  #est <- nlm(f=obj.f, p=ini, hessian=TRUE, gradtol = 1e-05)
  return(est)
}


logL_pwc_norm_withV.f <- function(scen, est, del, time, x, X0, Z0, V, brks){
  
  r <- ifelse(is.na(x), 0, 1)
  len <- length(brks)+1
  
  alp = exp(est[1:len]) #c(exp(para[1]), 1)
  
  if(scen=="sc"){
    eta1 = est[len+1]
    beta1 = est[len+2]
    
    eta2 = est[len+2+(1:(ncol(Z0)))]
    beta2 = est[len+2+ncol(Z0)+(1:(ncol(X0)))]
    gam2 = est[len+2+ncol(Z0)+ncol(X0)+(1:ncol(V))]
    sigma2 = exp(est[len+2+ncol(Z0)+ncol(X0)+ncol(V)+1])
    
  }else if(scen=="sa"){
    eta1 = est[len+1]
    beta1 = 0#est[len+2]
    
    eta2 = est[len+1+(1:(ncol(Z0)))]
    beta2 = est[len+1+ncol(Z0)+(1:(ncol(X0)))]
    gam2 = est[len+1+ncol(Z0)+ncol(X0)+(1:ncol(V))]
    sigma2 = exp(est[len+1+ncol(Z0)+ncol(X0)+ncol(V)+1])
    
  }else if(scen=="sb"){
    eta1 = 0#est[len+1]
    beta1 = est[len+1]
    
    eta2 = est[len+1+(1:(ncol(Z0)))]
    beta2 = est[len+1+ncol(Z0)+(1:(ncol(X0)))]
    gam2 = est[len+1+ncol(Z0)+ncol(X0)+(1:ncol(V))]
    sigma2 = exp(est[len+1+ncol(Z0)+ncol(X0)+ncol(V)+1])
  }
  
  muX1= drop(gam2 %*% t(V))
  muZ=drop(eta2%*%t(Z0)); muT=drop(beta2%*%t(X0))
  
  #res0 <- logLn_obs_pwc_norm_withV(r, del, time, x, eta1, beta1, muZ, muT, muX1, sigma2, alp, brks)
  res0 <- RtoC_logLn_obs_pwc_norm_withV(r, del, time, x, eta1, beta1, muZ, muT, muX1, sigma2, alp, brks)
  

  return(res0)
}


score_pwc_norm_withV.f <- function(grad=1e-06, scen, para, del, time, x, X0, Z0, V, brks){
  
  logL0 <- logL_pwc_norm_withV.f(scen, para, del, time, x, X0, Z0, V, brks)
  sc.list <- lapply(1:length(para), function(j){
    para.p <- para
    para.p[j] <- para[j]+grad
    
    logL.p <- logL_pwc_norm_withV.f(scen, para.p, del, time, x, X0, Z0, V, brks)
    (logL0-logL.p)/grad 
  })
  
  res <- do.call("cbind", sc.list)
  return(res)
}

hess_pwc_norm_withV.f <- function(grad=1e-06, scen, para, del, time, x, X0, Z0, V, brks){
  
  s0 <- score_pwc_norm_withV.f(grad, scen, para, del, time, x, X0, Z0, V, brks)
  h.list <- lapply(1:length(para), function(j){
    para.p <- para
    para.p[j] <- para[j]+grad
    
    s.p <- score_pwc_norm_withV.f(grad, scen, para.p, del, time, x, X0, Z0, V, brks)
    (colSums(s.p)-colSums(s0))/grad 
  })
  
  res <- do.call("cbind", h.list)
  return(res)
  
}

ase_pwc_norm_withV.f <- function(grad=1e-06, scen, est, del, time, x, X0, Z0, V, brks){
  # score vector
  score.mat = score_pwc_norm_withV.f(grad, scen, est$par, del, time, x, X0, Z0, V, brks)

  hess.mat = est$hess 
  B = t(score.mat) %*% score.mat
  A = (hess.mat)

  avar = ginv(A)%*% B%*% ginv(A)
  ase = sqrt(diag(avar))
  res = list(ase=ase, A=A, B=B, score=colSums(score.mat), avar=avar)
  return(res)
}



