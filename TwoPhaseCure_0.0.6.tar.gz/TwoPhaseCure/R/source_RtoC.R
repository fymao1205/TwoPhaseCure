RtoC_logLn_obs_pwc_norm_H0 <- function(del, time, muZ, muT, alp, brks) {

  del_size  <- length(del)
  alp_size  <- length(alp)
  brks_size <- length(brks)
  res       <- rep(-999999, del_size)

  tmp <- .C("C_logLn_obs_pwc_norm_H0", as.integer(del), as.double(time), 
            as.double(muZ), as.double(muT), as.double(alp), as.double(brks), 
            as.integer(del_size), as.integer(alp_size), as.integer(brks_size), 
            res=as.double(res),
            PACKAGE="TwoPhaseCure")
  res <- tmp$res
  res
}

RtoC_logLn_obs_pwc_norm <- function(r, del, time, x, eta1, beta1, muZ, muT, 
                                    muX1, sigma2, alp, brks) {

  del_size  <- length(del)
  alp_size  <- length(alp)
  brks_size <- length(brks)
  res       <- rep(-999999, del_size)

  tmp <- .C("C_logLn_obs_pwc_norm", as.integer(r), as.integer(del), as.double(time), 
            as.double(x), as.double(beta1), as.double(eta1), as.double(muZ), 
            as.double(muT), as.double(muX1), as.double(sigma2), as.double(alp), 
            as.double(brks), 
            as.integer(del_size), as.integer(alp_size), as.integer(brks_size),
            res=as.double(res),
            NAOK=TRUE, PACKAGE="TwoPhaseCure")
  res <- tmp$res
  res
}

RtoC_logLn_obs_pwc_norm_withV <- function(r, del, time, x, eta1, beta1, muZ, muT, 
                                    muX1, sigma2, alp, brks) {

  del_size  <- length(del)
  alp_size  <- length(alp)
  brks_size <- length(brks)
  res       <- rep(-999999, del_size)

  # x contains NAs

  tmp <- .C("C_logLn_obs_pwc_norm_withV", as.integer(r), as.integer(del), as.double(time), 
            as.double(x), as.double(beta1), as.double(eta1), as.double(muZ), 
            as.double(muT), as.double(muX1), as.double(sigma2), as.double(alp), 
            as.double(brks), 
            as.integer(del_size), as.integer(alp_size), as.integer(brks_size),
            res=as.double(res),
            NAOK=TRUE, PACKAGE="TwoPhaseCure")
  res <- tmp$res

  res
}


RtoC_vHpwc_H0 <- function(t, muT, alp, brks) {

  t_size    <- length(t)
  alp_size  <- length(alp)
  brks_size <- length(brks)
  res       <- rep(-999999, t_size)

  tmp <- .C("C_vHpwc_H0", as.double(t), as.double(muT), as.double(alp), as.double(brks), 
            as.integer(t_size), as.integer(alp_size), as.integer(brks_size),
            res=as.double(res),
            PACKAGE="TwoPhaseCure")
  res <- tmp$res
  res
}

RtoC_vppwc_H0 <- function(t, muT, alp, brks) {

  t_size    <- length(t)
  alp_size  <- length(alp)
  brks_size <- length(brks)
  res       <- rep(-999999, t_size)

  tmp <- .C("C_vppwc_H0", as.double(t), as.double(muT), as.double(alp), as.double(brks), 
            as.integer(t_size), as.integer(alp_size), as.integer(brks_size),
            res=as.double(res),
            PACKAGE="TwoPhaseCure")
  res <- tmp$res
  res
}



