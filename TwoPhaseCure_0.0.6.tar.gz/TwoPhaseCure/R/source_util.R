tpc.getVarType <- function(x) {

  if (is.numeric(x)) {
    if (all(x %in% 0:1)) {
      ret <- "binary"
    } else {
      ret <- "cont"
    }
  } else {
    ret <- "cat"
  }
  ret
}

tpc.getVarTypes <- function(data, vars) {

  nvars <- length(vars)
  if (!nvars) return(NULL)
  ret <- list()
  for (i in 1:nvars) {
    var  <- vars[i]
    x    <- data[, var, drop=TRUE]
    type <- tpc.getVarType(x)
    ret[[var]] <- type 
  }
  ret
}

tpc.addDummyVars <- function(data, var) {

  form <- as.formula(paste0("~ ", var))
  mat  <- model.matrix(form, data=data)
  mat  <- mat[, -1, drop=FALSE]
  cx   <- colnames(data)
  cm   <- colnames(mat)
  rm   <- rownames(mat)
  if (!any(cm %in% cx)) {
    data[, cm]   <- NA
    data[rm, cm] <- mat
  } else {
    while (1) {
      cm <- paste0(".", cm)
      if (!any(cm %in% cx)) break
    }
    data[, cm]   <- NA
    data[rm, cm] <- mat
  }
  list(data=data, dvars=cm)
}

tpc.addAllDummyVars <- function(data, vars, obj) {

  vars    <- unique(vars)
  nvars   <- length(vars)
  if (!nvars) return(list(data=data, obj.list=obj))
  vartype   <- obj$vartype
  catvars   <- NULL
  dummyvars <- list() 
  varlevels <- list()
  for (i in 1:nvars) {
    var  <- vars[i]
    type <- vartype[[var, exact=TRUE]]
    if (type %in% "cat") {
      data[, var]      <- as.factor(data[, var, drop=TRUE])
      tmp              <- tpc.addDummyVars(data, var)
      data             <- tmp$data
      dvars            <- tmp$dvars
      catvars          <- c(catvars, var)
      dummyvars[[var]] <- dvars
      varlevels[[var]] <- levels(data[, var]) 
    }
  } 
  obj$catvars   <- catvars
  obj$dummyvars <- dummyvars
  obj$varlevels <- varlevels

  list(data=data, obj.list=obj)

}

