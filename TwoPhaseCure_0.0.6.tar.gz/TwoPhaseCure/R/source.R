twoPhaseCure <- function(data, time.col, status.col, exposure.col, 
                         aux.cols.T, aux.cols.Z, aux.cols.V,  
                         exposure.type=NULL,
                         phaseII.design="BRSD", phaseII.nsamp=NULL, BRSD.wgt=0.5,
                         scenario="c", pwc.cutpoints=c(1/3, 2/3), 
                         em.maxiter=1000, em.eps=1e-4) {

  check_data(data)
  check_time.col(time.col, data) 
  check_status.col(status.col, data)
  check_exposure.col(exposure.col, data) 
  check_cols(aux.cols.T, "aux.cols.T", data, min=1)
  check_cols(aux.cols.Z, "aux.cols.Z", data, min=1)
  check_cols(aux.cols.V, "aux.cols.V", data, min=1)
  check_int(em.maxiter, "em.maxiter", min=1)
  check_num(em.eps, "em.eps", min=0, max=1)
  check_phaseII.design(phaseII.design)
  check_num(BRSD.wgt, "BRSD.wgt", min=0, max=1)
  if (length(phaseII.nsamp)) check_int(phaseII.nsamp, "phaseII.nsamp")
  check_scenario(scenario)
  pwc.cutpoints <- check_cuts(pwc.cutpoints)
  check_exposure.type(exposure.type)

  obj <- list(time.col=time.col, status.col=status.col, exposure.col=exposure.col, 
              aux.cols.T=aux.cols.T, aux.cols.Z=aux.cols.Z, aux.cols.V=aux.cols.V,
              phaseII.design=phaseII.design, phaseII.nsamp=phaseII.nsamp, 
              BRSD.wgt=BRSD.wgt, scenario=scenario, pwc.cutpoints=pwc.cutpoints,
              phase1.design=c("cbar", "del"), em.maxiter=em.maxiter, em.eps=em.eps,
              exposure.type=exposure.type)
  ret <- tpc.main(data, obj)
  ret
}

tpc.main <- function(data, obj) {

  DEBUG      <- 0
  obj$DEBUG  <- DEBUG
  if (DEBUG) cat("Begin: tpc.main\n")

  T    <- obj[["aux.cols.T", exact=TRUE]]
  Z    <- obj[["aux.cols.Z", exact=TRUE]]
  V    <- obj[["aux.cols.V", exact=TRUE]]
  yv   <- obj$status.col
  tv   <- obj$time.col
  ev   <- obj$exposure.col

  # Get variable types for all variables
  vars <- unique(c(T, Z, V, yv, tv, ev))
  obj$vartype <- tpc.getVarTypes(data, vars) 

  # Remove missing data, but not for exposure
  vars <- unique(c(T, Z, V, yv, tv))
  dat1 <- tpc.removeMissing(data, vars, obj$vartype)

  # Add dummy variables if needed
  vars <- unique(c(T, Z, V))
  tmp  <- tpc.addAllDummyVars(dat1, vars, obj) 
  dat1 <- tmp$data 
  obj  <- tmp$obj.list
  rm(tmp); gc()

  # Replace categorical variables with their dummy vars
  dvars.list <- obj$dummyvars
  if (length(dvars.list)) {
    obj[["aux.cols.T"]] <- tpc.replaceCatVars(T, dvars.list)
    obj[["aux.cols.Z"]] <- tpc.replaceCatVars(Z, dvars.list)
    obj[["aux.cols.V"]] <- tpc.replaceCatVars(V, dvars.list)
  }

  # Save original variable names
  obj$exposure.col0 <- obj$exposure.col
  obj$aux.cols.T0   <- obj[["aux.cols.T", exact=TRUE]]
  obj$aux.cols.Z0   <- obj[["aux.cols.Z", exact=TRUE]]
  obj$aux.cols.V0   <- obj[["aux.cols.V", exact=TRUE]]

  # Rename variables if needed. obj$aux.cols.T, etc will be updated
  tmp  <- tpc.checkAllVarNames(dat1, obj)
  dat1 <- tmp$data
  obj  <- tmp$obj
  rm(tmp); gc()

  # Keep only the columns we need
  dat1 <- tpc.setupPhase1Data(dat1, obj)

  # Get the exposure type, if NULL
  obj  <- tpc.setExposureType(dat1, obj)

  # Set objects
  obj <- tpc.setObjects(obj, dat1)

  # Phase I stratification
  if (DEBUG) cat("Call: phaesI_strat.f\n")
  phI_strat <- phaesI_strat.f(pcuts=obj$pwc.cutpoints, dat1, 
                              design.factor=obj$phase1.design)

  # fit a reduced model under H0: beta1=0 in phase I
  est.H0 <- tpc.get.est.H0(dat1, obj)

  # residual-dependent sampling 
  phII_sel <- tpc.get.phII_sel(obj, phI_strat, est.H0) 

  # Estimate parameters and variances
  ret <- tpc.getEstAndVar(dat1, obj, est.H0, phII_sel) 

  ret <- tpc.setReturnObj(phI_strat, phII_sel, ret, obj, dat1) 

  if (DEBUG) cat("End: tpc.main\n")

  ret
}

tpc.setExposureType <- function(data, obj) {
  
  type <- obj[["exposure.type", exact=TRUE]]
  if (!length(type)) {
    x    <- data[, obj$exposure.col, drop=TRUE]
    type <- tpc.getVarType(x) 
  }
  if (!(type %in% c("binary", "cont"))) {
    stop("ERROR: exposure.col must be numeric")
  }
  obj$exposure.type <- type
  obj
}


tpc.get.est.H0 <- function(dat1, obj) {

  DEBUG <- obj$DEBUG
  if (DEBUG) cat("Begin: tpc.get.est.H0\n")

  covsX <- obj[["aux.cols.T", exact=TRUE]]
  covsZ <- obj[["aux.cols.Z", exact=TRUE]]
  if (obj$exposure.type == "binary") {
    eta0  <- rep(0.01, length(covsZ)+1)  # For susceptibility model Z
    beta0 <- rep(0.01, length(covsX))    # For failure time model X
    if (!length(beta0)) beta0 <- NULL

    # fit a reduced model under H0: beta1=0 in phase I
    if (DEBUG) cat("Call: em_coxph_H0\n")
    est.H0 <- em_coxph_H0(dat1, covsX, covsZ, eta0, beta0, 
                          emmax=obj$em.maxiter, eps=obj$em.eps)
  } else {
    # specify the cutpoints (using the empirical tertiles of the observed failure time)
    #   for the PWC constant hazard model
    X0     <- tpc.getCovMat(dat1, covsX, add.int=0)
    Z0     <- tpc.getCovMat(dat1, covsZ, add.int=1)
    if (DEBUG) cat("Call: rldt_est_pwc_H0.f\n")
    est.H0 <- rldt_est_pwc_H0.f(dat1$del, dat1$time, X0, Z0, obj$brks)
  }
  if (DEBUG) cat("End: tpc.get.est.H0\n")
  est.H0
}

tpc.get.phII_sel <- function(obj, phI_strat, est.H0) {

  DEBUG <- obj$DEBUG
  if (DEBUG) cat("Begin: tpc.get.phII_sel\n")

  covsX <- obj[["aux.cols.T", exact=TRUE]]
  covsZ <- obj[["aux.cols.Z", exact=TRUE]]

  if (obj$exposure.type == "binary") {
    if (DEBUG) cat("Call: designPhII_resid_coxph_withV\n")
    phII_sel <- designPhII_resid_coxph_withV(phaseI_strat=phI_strat, 
                    n2samp=obj$phaseII.nsamp, design=obj$phII.design, 
                    obj$BRSD.wgt, covsX, covsZ, 
                    est.H0$beta, est.H0$eta, est.H0$lam0, est.H0$tk)$sel
  } else {
    if (DEBUG) cat("Call: designPhII_resid_pwc_noV\n")
    phII_sel <- designPhII_resid_pwc_noV(phaseI_strat=phI_strat, obj$phaseII.nsamp, 
                                         design=obj$phII.design, obj$BRSD.wgt, 
                                         covsX, covsZ, est.H0$est, obj$brks)$sel
  }
  if (DEBUG) cat("End: tpc.get.phII_sel\n")
  phII_sel
}

tpc.getEstAndVar <- function(dat1, obj, est.H0, phII_sel) {

  if (obj$exposure.type == "binary") {
    ret <- tpc.getEstAndVar.binary(dat1, obj, est.H0, phII_sel)
  } else {
    ret <- tpc.getEstAndVar.cont(dat1, obj, est.H0, phII_sel)
  }
  ret
}

tpc.getEstAndVar.binary <- function(dat1, obj, est.H0, phII_sel) {

  DEBUG <- obj$DEBUG
  if (DEBUG) cat("Begin: tpc.getEstAndVar.binary\n")

  # Get objects needed for estimation
  if (DEBUG) cat("Call: tpc.getEstInfObj\n")
  tmp <- tpc.getEstInfObj(dat1, phII_sel, obj)

  # estimation after design 
  if (DEBUG) cat("Call: em_coxph\n")
  est <- em_coxph(tmp$Status, tmp$Time, obj$scen, tmp$dat.z, tmp$X, tmp$Z, tmp$V, 
                  est.H0, obj$em.maxiter, obj$em.eps)

  # asymptotic variance computation  
  if (DEBUG) cat("Call: CureCox.Louis.varMatrix\n")
  asvar <- CureCox.Louis.varMatrix(est$lam0, est$tk, est$pdata$id, est$pdata$pz, 
                                   est$pdata$del, est$pdata$time, est$pdata$px, 
                                   tmp$X, tmp$Z, tmp$V, est$beta, est$eta, est$gam, 
                                   est$pdata$wgt1, est$pdata$wgt2)

  est$pdata <- NULL
  est$tk    <- NULL
  est$lam0  <- NULL

  if (DEBUG) cat("End: tpc.getEstAndVar.binary\n")
  list(est=est, asvar=asvar)
}

tpc.getEstAndVar.cont <- function(dat1, obj, est.H0, phII_sel) {

  DEBUG <- obj$DEBUG
  if (DEBUG) cat("Begin: tpc.getEstAndVar.cont\n")

  if (DEBUG) cat("Call: tpc.getEstInfObj\n")
  tmp     <- tpc.getEstInfObj(dat1, phII_sel, obj)
  dt.phII <- tmp$dt.phII
  rm(tmp); gc()

  X0  <- tpc.getCovMat(dat1, obj[["aux.cols.T", exact=TRUE]], add.int=0) 
  Z0  <- tpc.getCovMat(dat1, obj[["aux.cols.Z", exact=TRUE]], add.int=1) 
  V   <- tpc.getCovMat(dat1, obj[["aux.cols.V", exact=TRUE]], add.int=1) 

  scen  <- obj$scen
  brks  <- obj$brks
  nbrks <- length(brks)
  if (scen == "sc") {
    ini <- c(est.H0$est[1:(nbrks+1)],    0.01, 0.01, 
             est.H0$est[-(1:(nbrks+1))], rep(0.01, ncol(V)), 0.01)
  } else if (scen == "sb") {
    ini <- c(est.H0$est[1:(nbrks+1)],    0.01, 
             est.H0$est[-(1:(nbrks+1))], rep(0.01, ncol(V)), 0.01)
  } else {
    ini <- c(est.H0$est[1:(nbrks+1)],    0.01, 
             est.H0$est[-(1:(nbrks+1))], rep(0.01, ncol(V)), 0.01)
  }

  est <- rldt_est_pwc_withV.f(ini=ini, scen, dt.phII$del, dt.phII$time, 
                        dt.phII$x, X0, Z0, V, brks)
  ase <- ase_pwc_norm_withV.f(grad=1e-08, scen, est, dt.phII$del, dt.phII$time, 
                        dt.phII$x, X0, Z0, V, brks)

  if (DEBUG) cat("End: tpc.getEstAndVar.cont\n")

  list(est=est, ase=ase)
}

tpc.setReturnObj <- function(phI, phII, ret, obj, dat) {

  DEBUG <- obj$DEBUG
  if (DEBUG) cat("Begin: tpc.setReturnObj\n")

  # Continuous case
  # ret$est contains names par, value, hessian
  # ret$ase contains ase, A, B, score, avar. 

  est      <- ret$est
  x        <- phI$dt_ext
  strata   <- phI$ref.strata
  rn       <- rownames(x)
  x        <- unlist(x[, "group", drop=TRUE])
  names(x) <- rn
  phaseI   <- list(strata=x)
  x        <- phII$s_prob
  s_prob   <- tpc.setNames(x, strata)
  s_m      <- tpc.setNames(phII$s_m, strata)
  x        <- rownames(dat)[phII$s_id]
  phaseII  <- list(ids=x, prob=s_prob, n=s_m) 
  tmp      <- tpc.getParmNames(obj)
  enms     <- tmp$eta
  bnms     <- tmp$beta
  gnms     <- tmp$gamma
  anms     <- tmp$logalpha

  if (obj$exposure.type == "binary") {
    binFlag <- TRUE
    eta     <- tpc.setNames(est$eta,  enms)
    beta    <- tpc.setNames(est$beta, bnms)
    gamma   <- tpc.setNames(est$gam,  gnms) 

    # order of asvar for binary type is eta, gamma, beta
    asvar <- tpc.setNames(ret$asvar, c(enms, gnms, bnms)) 
    ase   <- sqrt(diag(asvar))
  } else {
    binFlag <- FALSE
    vec     <- est$par
    nms     <- tmp$cont
    if (length(vec) != length(nms)) {
      print(vec)
      print(nms)
      stop("INTERNAL CODING ERROR")
    }
    names(vec) <- nms
    eta   <- vec[enms]
    beta  <- vec[bnms]
    gamma <- vec[gnms]
    asvar <- tpc.setNames(ret$ase$avar, nms) 
    ase   <- tpc.setNames(ret$ase$ase,  nms)       
    logal <- vec[anms]
  }

  if (binFlag) {
    ret <- list(est.susceptibility=eta, est.failure_time=beta, 
                est.covariate=gamma, se=ase, covariance=asvar,
                phaseI=phaseI, phaseII=phaseII)
  } else {
    ret <- list(est.susceptibility=eta, est.failure_time=beta, 
                est.covariate=gamma, est.log_alpha=logal,
                se=ase, covariance=asvar,
                phaseI=phaseI, phaseII=phaseII)
  }

  if (DEBUG) cat("End: tpc.setReturnObj\n")
  ret
}

tpc.getParmNames <- function(obj) {

  
  nbrks    <- length(obj$brks)
  logalpha <- paste0("log_alpha", 1:(nbrks + 1))

  Tcovs    <- obj[["aux.cols.T0", exact=TRUE]]
  Zcovs    <- obj[["aux.cols.Z0", exact=TRUE]]
  Vcovs    <- obj[["aux.cols.V0", exact=TRUE]]
  ecov     <- obj$exposure.col0
  scen     <- obj$scenario
  iv       <- "(Intercept)"
  
  enms  <- c(iv, Zcovs, ecov)
  bnms  <- c(Tcovs, ecov)
  gnms  <- c(iv, Vcovs)
  enms  <- paste0("Z.", enms)
  bnms  <- paste0("T.", bnms)
  gnms  <- paste0("V.", gnms)
  elen  <- length(enms)
  blen  <- length(bnms)
  signm <- "sigma"

  # parm vector for cont case
  if (scen == "a") {
    nms <- c(logalpha, enms[elen], enms[-elen], bnms[-blen], gnms, signm)
  } else if (scen == "b") {
    nms <- c(logalpha, bnms[blen], enms[-elen], bnms[-blen], gnms, signm)
  } else {
    nms <- c(logalpha, enms[elen], bnms[blen], enms[-elen], bnms[-blen], gnms, signm)
  }

  list(eta=enms, beta=bnms, gamma=gnms, 
       logalpha=logalpha, cont=nms)
}

tpc.setNames <- function(x, nms) {

  ret <- x
  d   <- dim(x)
  len <- length(nms)
  if (!length(d)) {
    if (length(x) == len) names(ret) <- nms
  } else {
    # Matrix
    if (d[1] == len) rownames(ret) <- nms
    if (d[2] == len) colnames(ret) <- nms 
  }
  ret
}

tpc.renamecol <- function(data, obj, col) {

  expv  <- obj$exposure.col
  auxT  <- obj[["aux.cols.T", exact=TRUE]]
  auxZ  <- obj[["aux.cols.Z", exact=TRUE]]
  auxV  <- obj[["aux.cols.V", exact=TRUE]]
  timev <- obj$time.col
  yv    <- obj$status.col
  cx    <- colnames(data)
  id    <- match(col, cx)
  if (!length(id)) stop("ERROR 1")
  new <- col
  while (1) {
    new <- paste0(".", new)
    if (!(new %in% cx)) {
      cx[id]         <- new
      colnames(data) <- cx
      break 
    }
  }

  if (col == expv) obj$exposure.col <- new
  if (col == timev) obj$time.col <- new
  if (col == yv) obj$status.col <- new
  if (col %in% auxT) {
    tmp            <- auxT == col
    auxT[tmp]      <- new
    obj$aux.cols.T <- auxT
  } 
  if (col %in% auxZ) {
    tmp            <- auxZ == col
    auxZ[tmp]      <- new
    obj$aux.cols.Z <- auxZ
  } 
  if (col %in% auxV) {
    tmp            <- auxV == col
    auxV[tmp]      <- new
    obj$aux.cols.V <- auxV
  } 

  list(data=data, obj=obj, new=new)
}

tpc.checkAllVarNames <- function(data, obj) {

  expv  <- obj$exposure.col
  auxv  <- c(obj[["aux.cols.T", exact=TRUE]], obj[["aux.cols.Z", exact=TRUE]],
             obj[["aux.cols.V", exact=TRUE]])
  timev <- obj$time.col
  yv    <- obj$status.col
  if (expv %in% auxv) stop("ERROR: exposure.col %in% aux.cols")
  if (expv == timev) stop("ERROR: exposure.col == time.col")
  if (expv == yv) stop("ERROR: exposure.col == status.col")
  if (timev == yv) stop("ERROR: time.col == status.col")
  if (timev %in% auxv) stop("ERROR: time.col %in% aux.cols")
  if (yv %in% auxv) stop("ERROR: status.col %in% aux.cols")

  # Rename variables if needed. "time", "del", and "id" are reserved
  allv <- c(expv, auxv, timev, yv)
  if (("time" %in% allv) & (timev != "time")) {
    tmp  <- tpc.renamecol(data, obj, "time")
    data <- tmp$data
    obj  <- tmp$obj
  } 
  if (("del" %in% allv) & (yv != "del")) {
    tmp  <- tpc.renamecol(data, obj, "del")
    data <- tmp$data
    obj  <- tmp$obj
  } 
  if ("id" %in% allv) {
    tmp  <- tpc.renamecol(data, obj, "id")
    data <- tmp$data
    obj  <- tmp$obj
  } 
  
  # Set rownames
  rn <- rownames(data)
  if (!length(rn)) rownames(data) <- as.character(1:nrow(data))

  list(data=data, obj=obj)
}

tpc.removeMissing <- function(data, vars, vartype) {

  ret  <- data
  keep <- rep(TRUE, nrow(data))
  for (v in vars) {
    type <- vartype[[v, exact=TRUE]]
    if (type == "cat") {
      keep <- keep & !is.na(ret[, v, drop=TRUE])
    } else {
      keep <- keep & is.finite(ret[, v, drop=TRUE])
    }
  }
  ret <- ret[keep, , drop=FALSE]
  if (nrow(ret) < 5) {
    stop("ERROR: too few rows of data left after removing missing/non-finite values")
  }
  ret
}

tpc.setupPhase1Data <- function(data, obj) {

  exp           <- obj$exposure.col
  aux           <- c(obj[["aux.cols.T", exact=TRUE]], 
                     obj[["aux.cols.Z", exact=TRUE]],
                     obj[["aux.cols.V", exact=TRUE]])
  vars          <- unique(c(obj$time.col, obj$status.col, exp, aux))
  vars2         <- vars[-(1:2)]
  ret           <- data[, vars, drop=FALSE]
  colnames(ret) <- c("time", "del", vars2)
  ret[, "id"]   <- 1:nrow(ret)
  
  ret
}

tpc.replaceCatVars <- function(vars, dvars.list) {

  if (!length(vars)) return(NULL)
  if (!length(dvars.list)) return(vars)

  nms <- names(dvars.list)
  cat <- vars %in% nms
  if (!any(cat)) return(vars)
  ret <- NULL
  for (i in 1:length(vars)) {
    var <- vars[i]
    if (cat[i]) {
      dvars <- dvars.list[[var, exact=TRUE]]
      if (!length(dvars)) stop("ERROR")
    } else {
      dvars <- var 
    }
    ret <- c(ret, dvars)
  }
  ret 
}

tpc.setObjects <- function(obj, data) {

  nm  <- "phaseII.design"
  nm2 <- "phII.design" 
  x   <- obj[[nm, exact=TRUE]]
  if (x == "RSD1") {
    obj[[nm2]] <- "RSD-Smu1"
  } else if (x == "RSD2") {
    obj[[nm2]] <- "RSD-Smu2"
  } else {
    obj[[nm2]] <- paste0("BRSD-eff-seq", obj$BRSD.wgt)
  }

  nm <- "phaseII.nsamp"
  x  <- obj[[nm, exact=TRUE]]
  if (!length(x)) x <- ceiling(nrow(data)/2)
  obj[[nm]] <- x

  nm    <- "scenario"
  scen  <- obj[[nm, exact=TRUE]]
  covsX <- obj[["aux.cols.T", exact=TRUE]]
  covsZ <- obj[["aux.cols.Z", exact=TRUE]]
  expv  <- obj[["exposure.col", exact=TRUE]]
  if (scen == "c"){
    obj$covXname <- c(covsX, "px")
    obj$covZname <- c(covsZ, "px") 
  } else if (scen == "b"){
    obj$covXname <- c(covsX, "px")
    obj$covZname <- covsZ
  } else{
    obj$covXname <- covsX
    obj$covZname <- c(covsZ, "px")
  }
  obj$covVname <- obj[["aux.cols.V", exact=TRUE]]
  obj$scen     <- paste0("s", scen)

  # specify the cutpoints (using the empirical tertiles of the observed failure time)
  #   for the PWC constand hazard model
  obj$brks <- quantile(data$time[data$del==1], obj$pwc.cutpoints) 

  obj
}

tpc.getEstInfObj <- function(dat1, phII_sel, obj) {

   # incomplete data set with partially missing covariate x
   dat.orig <- dat1
   ids      <- phII_sel$s_id
   if (length(ids)) {                   
     dat.orig$x[-ids] <- NA
     dat.orig$r       <- 1
     dat.orig$r[-ids] <- 0
   } else {
     stop("ERROR: no ids selected in phase II")
   } 

   if (obj$exposure.type != "binary") {
     return(list(dt.phII=dat.orig))
   }

   ###########################
   ##### Estimation and Inference #####
   ###########################
    
   #--- creating pseudo data set ---#
   Status      <- dat.orig$del
   Time        <- dat.orig$time
   dat.orig$id <- 1:nrow(dat.orig)
 
   # expand the dat.orig for missing covariate x
   px    <- c( subset(dat.orig, dat.orig$r==1)$x, rep(c(1,0), each=sum(1-dat.orig$r)) )
   dat.x <- cbind(rbind(subset(dat.orig, dat.orig$r==1),
                        subset(dat.orig, dat.orig$r==0),
                        subset(dat.orig, dat.orig$r==0)), px)
   dat.x <- as.data.frame(dat.x, stringsAsFactors=FALSE)
    
   # expand the dat.x for susceptibility model 
   pz    <- c(rep(1, dim(dat.x)[1]), rep(0, sum(1-dat.x$del)))
   dat.z <- cbind(rbind(subset(dat.x, dat.x$del==1),
                        subset(dat.x, dat.x$del==0),
                        subset(dat.x, dat.x$del==0)),pz)
   dat.z <- dat.z[order(dat.z$id),]
    
   # weights for missing covariates
   p1         <- mean(dat.orig$x,na.rm=T)
   w1         <- ifelse(dat.z$px==1, p1, 1-p1)
   dat.z$wgt1 <- ifelse(dat.z$r==1,1,w1)
    
   # weights for latent susceptibility
   w2         <- dat.z$del
   dat.z$wgt2 <- ifelse(dat.z$pz==1,w2,1-w2)
    
   # prepare the covariate matrix: 
   # X for the failure time model; Z for the susceptibility model; V for the covariate model
   X <- tpc.getCovMat(dat.z, obj$covXname, add.int=0) 
   Z <- tpc.getCovMat(dat.z, obj$covZname, add.int=1) 
   V <- tpc.getCovMat(dat.z, obj$covVname, add.int=1) 

   list(Status=Status, Time=Time, X=X, Z=Z, V=V, dat.z=dat.z)
}

tpc.getCovMat <- function(dat, covs, add.int=1) {

  ret <- NULL
  if (length(covs)) {
    if (add.int) {
      ret <- as.matrix(cbind(rep(1,nrow(dat)), dat[, covs, drop=FALSE]))
    } else {
      ret <- as.matrix(dat[, covs, drop=FALSE])
    }
  } else if (add.int) {
    ret <- matrix(1, nrow=nrow(dat), ncol=1)  
  }
  ret
}
