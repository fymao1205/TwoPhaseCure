
obsest_H0.f <- function(del, time, v.mat, pos.cov.T, pos.cov.Z){
  
  p1 = length(pos.cov.T)
  p2 = length(pos.cov.Z)
  
  obj.f <- function(para){
    
    alp = exp(para[1]+v.mat[,pos.cov.T,drop=FALSE]%*% para[1+(1:p1)])
    #alp = exp(para[1])
    pi.z = expit.f(para[p1+2]+v.mat[,pos.cov.Z,drop=FALSE]%*% para[p1+2+(1:p2)])
    #res0 <- logL1n_comp_g_Z1_x(wgt2, del, time, x, cov, beta1, alp)
    
    res0 <- (del*(log( alp*exp(-alp*time) ) + log(pi.z) )+
               (1-del)*log( 1-(1-exp(-alp*time))*pi.z))
    #res0 <- ifelse(is.finite(res0), res0, 0)
    #res0 <- ifelse(is.na(res0), 0, res0)
    res <- -sum(res0)
    
    # print(para)
    # print(res)
    
    return(res)
    
  }
  
  #est <- optim(par=rep(0.01,5), obj.f, method=("L-BFGS-B"), hessian=TRUE)
  est <- nlm(f=obj.f, p=rep(0.01, p1+p2+2), hessian=TRUE)
  return(est)
}



rkd_ext.f <- function(k, n2samp, qzi, phaseI_strat){
  
  dt_ext = phaseI_strat$dt_ext
  ref.group = phaseI_strat$ref.strata
  strata.n = phaseI_strat$strata.n
  n <- sum(strata.n)
  #dt_ext$id <- 1:n
  
  #wrs <- w*(res1^2)+(1-w)*(res2^2)
  ord_qzi <- order(qzi)
  
  #k = min((round(n2samp/2)), sum(phI_strat$dt_ext$del1))
  s_id <- dt_ext$id[ord_qzi[c(1:(n2samp-k), (n-k+1):n)]]
  
  s_dt = subset(dt_ext, dt_ext$id %in% s_id)
  
  s_prob <- sapply(1:length(ref.group), function(g){
    
    if(any(s_dt$group %in% ref.group[g])){
      
      dim(subset(s_dt, s_dt$group %in% ref.group[g]))[1]/strata.n[g]
      
    }else{
      
      0
    }
    
  })
  
  s_m <- sapply(1:length(ref.group), function(g){
    
    if(any(s_dt$group %in% ref.group[g])){
      
      nrow(subset(s_dt, s_dt$group %in% ref.group[g]))
      
    }else{
      
      0
    }
  })
  
  res <- list(s_prob=s_prob,
              s_id=s_id,
              s_m=s_m)
  
  return(res)
  
}


# qzi = distance, loglik
rkd_max.f <- function(n2samp, qzi, phaseI_strat){
  
  dt_ext = phaseI_strat$dt_ext
  ref.group = phaseI_strat$ref.strata
  strata.n = phaseI_strat$strata.n
  n <- sum(strata.n)
  dt_ext$id <- 1:n
  
  #wrs <- w*(res1^2)+(1-w)*(res2^2)
  ord_qzi <- order(qzi)
  
  s_id <- ord_qzi[c((n-round(n2samp)+1):n)]
  
  s_dt = subset(dt_ext, dt_ext$id %in% s_id)
  
  s_prob <- sapply(1:length(ref.group), function(g){
    
    if(any(s_dt$group %in% ref.group[g])){
      
      dim(subset(s_dt, s_dt$group %in% ref.group[g]))[1]/strata.n[g]
      
    }else{
      
      0
    }
    
  })
  
  res <- list(s_prob=s_prob,
              s_id=s_id)
  
  return(res)
  
}

rkd_ext_opt_noV.f <- function(k, n2samp, qzi, phaseI_strat){
  
  dt_ext = phaseI_strat$dt_ext
  ref.group = phaseI_strat$ref.strata
  strata.n = phaseI_strat$strata.n
  n <- sum(strata.n)
  dt_ext$id <- 1:n
  
  #indV0=which(dt_ext$v==0)
  #nV0 = length(indV0)
  #indV1 = which(dt_ext$v == 1)
  #nV1 = length(indV1)
  
  #### optimal sampling ####################################################################################
  
  #order_resi0 = order(qzi[indV0])
  #order_resi1 = order(qzi[indV1])
  order_resi = order(qzi)
  
  best_k = k#round(n2samp*0.15)
  # phase2_id = c(indV0[order_resi0[1:best_k]], indV0[order_resi0[(nV0-best_k+1):nV0]], 
  #               indV1[order_resi1[1:(n2samp/2-best_k)]], indV1[order_resi1[(nV1-(n2samp/2-best_k)+1):nV1]])
  phase2_id=dt_ext$id[order_resi[c(1:(n2samp-best_k), (n-best_k+1):n)]]
  mart.opt = qzi[phase2_id]
  #simZ.opt = dt_ext$v[phase2_id]
  best_var = var(mart.opt)#(var(mart.opt[which(simZ.opt == 0)])*sum(simZ.opt==0)+var(mart.opt[which(simZ.opt == 1)])*sum(simZ.opt==1))/n2samp
  
  for (k in (best_k+1):(n2samp/2))
  {
    # phase2_id = c(indV0[order_resi0[1:k]], indV0[order_resi0[(nV0-k+1):nV0]], 
    #               indV1[order_resi1[1:(n2samp/2-k)]], indV1[order_resi1[(nV1-(n2samp/2-k)+1):nV1]])
    phase2_id=dt_ext$id[order_resi[c(1:(n2samp-k), (n-k+1):n)]]
    mart.opt = qzi[phase2_id]
    #simZ.opt = dt_ext$v[phase2_id]
    tmp_var = var(mart.opt)#(var(mart.opt[which(simZ.opt == 0)])*sum(simZ.opt==0)+var(mart.opt[which(simZ.opt == 1)])*sum(simZ.opt==1))/n2samp
    if (tmp_var > best_var) {
      best_k = k
      best_var = tmp_var
    }
  }
  
  # s_id = c(indV0[order_resi0[1:best_k]], indV0[order_resi0[(nV0-best_k+1):nV0]], 
  #          indV1[order_resi1[1:(n2samp/2-best_k)]], indV1[order_resi1[(nV1-(n2samp/2-best_k)+1):nV1]])
  # 
  # s_id = dt_ext$id[s_id]
  s_id=dt_ext$id[order_resi[c(1:(n2samp-best_k), (n-best_k+1):n)]]
  
  s_dt = subset(dt_ext, dt_ext$id %in% s_id)
  s_prob <- sapply(1:length(ref.group), function(g){
    
    if(any(s_dt$group %in% ref.group[g])){
      
      dim(subset(s_dt, s_dt$group %in% ref.group[g]))[1]/strata.n[g]
      
    }else{
      
      0
    }
    
  })
  
  s_m <- sapply(1:length(ref.group), function(g){
    
    if(any(s_dt$group %in% ref.group[g])){
      
      nrow(subset(s_dt, s_dt$group %in% ref.group[g]))
      
    }else{
      
      0
    }
    
  })
  
  res <- list(s_prob=s_prob,
              s_id=s_id,
              s_m=s_m)
  
  return(res)
  
  
}
