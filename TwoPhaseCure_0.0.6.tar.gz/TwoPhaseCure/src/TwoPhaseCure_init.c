
#include <stdlib.h> // for NULL
#include <R_ext/Rdynload.h>

/* FIXME:
Check these declarations against the C/Fortran source code.
*/

/* .C calls */
extern void C_logLn_obs_pwc_norm_H0_ORIG(void *, void *, void *, void *, void *, void *, void *, void *, void *, void *);
extern void C_logLn_obs_pwc_norm_ORIG(void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *); 
extern void C_vHpwc_H0_ORIG(void *, void *, void *, void *, void *, void *, void *, void *);
extern void C_vppwc_H0_ORIG(void *, void *, void *, void *, void *, void *, void *, void *);


extern void C_logLn_obs_pwc_norm_H0(void *, void *, void *, void *, void *, void *, void *, void *, void *, void *);
extern void C_logLn_obs_pwc_norm_withV(void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *, void *);
extern void C_vHpwc_H0(void *, void *, void *, void *, void *, void *, void *, void *);
extern void C_vppwc_H0(void *, void *, void *, void *, void *, void *, void *, void *);

static const R_CMethodDef CEntries[] = {
  {"C_logLn_obs_pwc_norm_H0_ORIG", (DL_FUNC) &C_logLn_obs_pwc_norm_H0_ORIG, 10},
  {"C_logLn_obs_pwc_norm_H0",      (DL_FUNC) &C_logLn_obs_pwc_norm_H0, 10},
  {"C_logLn_obs_pwc_norm_ORIG",    (DL_FUNC) &C_logLn_obs_pwc_norm_ORIG,    16},
  {"C_logLn_obs_pwc_norm_withV",   (DL_FUNC) &C_logLn_obs_pwc_norm_withV,   16},
  {"C_vHpwc_H0_ORIG",              (DL_FUNC) &C_vHpwc_H0_ORIG,               8},
  {"C_vppwc_H0_ORIG",              (DL_FUNC) &C_vppwc_H0_ORIG,               8},
  {"C_vHpwc_H0",                   (DL_FUNC) &C_vHpwc_H0,                    8},
  {"C_vppwc_H0",                   (DL_FUNC) &C_vppwc_H0,                    8},
  {NULL, NULL, 0}
};

void R_init_TwoPhaseCure(DllInfo *dll)
{
  R_registerRoutines(dll, CEntries, NULL, NULL, NULL);
  R_useDynamicSymbols(dll, FALSE);
}
